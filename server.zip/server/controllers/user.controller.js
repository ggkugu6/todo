const db = require('../db.js')
const bcrypt= require('bcrypt')
const jwt = require('jsonwebtoken')
const ApiError = require('../error/ApiError')

const generateJwt = (login) => {
    return jwt.sign(
    {login}, 
    'привет', 
    {expiresIn: '8h'}
    )
    }

class UserController{
    async createUser(req,res){
        const {name,last_name, login} = req.body
        const newPerson = await db.query('INSERT INTO "users" ("name", "last_name", "login") VALUES ($1, $2, $3) RETURNING *', [name, last_name, login])
        console.log(name, last_name, login)
        res.json(newPerson.rows[0])
    }
    async getUser(req,res){
        const users = await db.query('select * from users')
        res.json(users.rows)

    }
    async getOneUser(req,res){  /*возвращает конкрет юзера*/
        const id = req.params.user_id
        const user = await db.query('select * from users where user_id=$1', [id])
        res.json(user.rows)
    }
    async updateUser(req,res){
        const {
            user_id,
            name,
            last_name,
            surname,
            full_name,
            login,
            passsword,
            role
        } = req.body
        const user = await db.query(
        'update users set user_id=$1,name=$2,last_name=$3,surname=$4,full_name=$5,login=$6,passsword=$7,role=$8 RETURNING *',
        [user_id,name,last_name,surname,full_name,login,passsword,role]
        )
            res.json(user.rows[0])

    }
    async deleteUser(req,res){
        const id=req.params.user_id
        const user = await db.query ('delete from users where user_id=$1', [id])
        res.json(user.rows)
    }

    async registration(req,res,next){
        const{login, passsword} = req.body
        /*if(!login || !passsword){
            return next(ApiError.badRequest('Некорректный Логин или Пароль'))
        }*/
        /*const candidate = await db.query('select * from users where user_id=$1', [user_id])*/
        /*if (candidate) {
            return next(ApiError.badRequest('Пользователь с таким Логин уже существует'))
        }*/
        const hashPassword = await bcrypt.hash(passsword, 5)
        const user = await db.query('INSERT INTO "users" (login, passsword) VALUES ($1, $2) RETURNING *', [login, {passsword: hashPassword}])
        /*const task = await db.query('INSERT INTO "tasks" ("title", "description", "priority", "status", "deleted_at", "ended_at", "creator_id", "responsible_id") VALUES ($1, $2, $3,$4, $5, $6,$7, $8) RETURNING *', 
        [title, description, priority, status, deleted_at, ended_at, creator_id, responsible_id])*/
        const token = generateJwt(login)
        return res.json({token})

    } 
    async login(req,res, next){
        const {login, passsword} = req.body
        const users = await db.query('select login, passsword as passsword from users where login=$1', [req.body.login])
        /*const isUser = await res.json(users.rows[0].login)*/
        if(!users.rows[0]){
            return next(ApiError.internal('Пользователь не найден'))
        }
        let jsonParse = JSON.parse(users.rows[0].passsword)
        let comparePassword = bcrypt.compareSync(passsword, jsonParse.passsword)
        if(!comparePassword){
            return next(ApiError.internal('Указан неверный пароль'))
        }
        const token = generateJwt(login)
        return res.json({token})

         
   
    }  

}
module.exports = new UserController() 